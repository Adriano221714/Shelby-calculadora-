// Servidor do assistente: a chave da API fica aqui (variável de ambiente), nunca no navegador.
// Para trocar de fornecedor de IA, altere apenas este ficheiro.
const SYS = "És o assistente da aplicação SHELBY CALCULATOR, de uso geral (estudo, escrita, programação, negócios, agronomia, quotidiano). Responde em português por defeito, de forma clara e organizada. Para qualquer resultado numérico usa SEMPRE a ferramenta «calcular» em vez de calcular de cabeça. Admite incerteza, distingue factos de estimativas, não inventes fontes e avisa quando o tema for de alto risco (saúde, direito, finanças).";
const TOOLS = [{
  name: "calcular",
  description: "Avalia uma expressão matemática (+ - * / ^ % ! parêntesis, sin cos tan asin acos atan ln log sqrt, pi, e; ângulos em graus). Devolve o resultado do motor local.",
  input_schema: { type: "object", properties: { expressao: { type: "string" } }, required: ["expressao"] },
}];
const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5";
const LIMIT = Number(process.env.RATE_LIMIT_PER_MIN || 20);
const hits = new Map(); // limite simples por IP (por instância do servidor)

const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "Content-Type": "application/json" } });

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Método não permitido" }, 405);
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return json({ error: "Assistente sem configuração", code: "not_configured" }, 503);

  const ip = req.headers.get("x-nf-client-connection-ip") || req.headers.get("x-forwarded-for") || "anon";
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < 60000);
  if (recent.length >= LIMIT) return json({ error: "Demasiados pedidos. Aguarde um minuto.", code: 429 }, 429);
  recent.push(now); hits.set(ip, recent);
  if (hits.size > 5000) hits.clear();

  let body;
  try { body = await req.json(); } catch { return json({ error: "Pedido inválido" }, 400); }
  const msgs = body && body.messages;
  if (!Array.isArray(msgs) || !msgs.length || msgs.length > 60 ||
      msgs.some((m) => !m || !["user", "assistant"].includes(m.role) || !(typeof m.content === "string" || Array.isArray(m.content))) ||
      JSON.stringify(msgs).length > 120000) return json({ error: "Pedido inválido" }, 400);

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: MODEL, max_tokens: 1500, system: SYS, tools: TOOLS, messages: msgs }),
    });
    if (!r.ok) {
      console.error("Erro do fornecedor de IA:", r.status);
      return json({ error: r.status === 429 ? "Serviço de IA ocupado. Tente de novo." : "Erro no serviço de IA (" + r.status + ")", code: r.status }, r.status === 429 ? 429 : 502);
    }
    const d = await r.json();
    return json({ content: d.content, stop_reason: d.stop_reason });
  } catch (e) {
    console.error("Falha de rede:", e && e.message);
    return json({ error: "Não foi possível contactar o serviço de IA" }, 502);
  }
};
export const config = { path: "/api/chat" };
